package examendiciembreAlejandroJimenez;

import java.util.Scanner;

public class Ejercicio_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Dime un numero");
		int num= input.nextInt();
		System.out.println("Dime el exponente");
		int exp= input.nextInt();
		int i=1;
		double respuesta = Math.pow(num, exp);
		System.out.print(num+"^"+exp+"=");
		while (i<num -1) {
			System.out.print(num+"x");
			i++;
		}
		System.out.print(num+"="+respuesta);
		

	}

}
