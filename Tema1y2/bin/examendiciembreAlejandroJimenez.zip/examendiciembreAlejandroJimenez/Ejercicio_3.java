package examendiciembreAlejandroJimenez;

import java.util.Scanner;

public class Ejercicio_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Dime un numero");
		int x= input.nextInt();
		System.out.println("Dime otro numero");
		int y= input.nextInt();
		int numAlto;
		int numBajo;
		int suma =0;
		if (x<y) {
			numAlto = y;
			numBajo = x;
		}
		else {
			numAlto = x;
			numBajo = y;
		}
		if (numBajo%2==0) {
			numBajo--;
		}
		for (suma= 0;numBajo<numAlto;numBajo=numBajo+2) {
			suma= suma + numBajo;
		}
		System.out.println("La suma de "+x+" y "+y+" es "+suma);
		

	}
	

}

