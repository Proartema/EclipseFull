package examendiciembreAlejandroJimenez;

import java.util.Scanner;

public class Ejercicio_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Dime un numero");
		int num= input.nextInt();
		int i=0;
		double h=0;
		double cifra;
		int nOut=num;
		double suma=0;
		while (nOut>0) {
			nOut= nOut/10;
			i++;
			
		}
		System.out.println("El numero "+num+" tiene "+i+" cifras.");
		System.out.println("Las cifras son ");
		for ( i= i-1 ; i>= 0; i--) {
			h = Math.pow(10, i);
		    cifra= (num/h)%10;
		    System.out.print((int)cifra+", ");
		    suma= suma + Math.pow(cifra, 3);

	}
		System.out.println("La suma de los cubos es "+suma);

}
}
