package examendiciembreAlejandroJimenez;

import java.util.Scanner;

public class Ejercicio_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Dime el año");
		int año= input.nextInt();
		System.out.println("Dime el mes");
		int mes= input.nextInt();
		
		 if (año%4 != año%100) {
			 switch (mes) 
				{ 
					case 1 -> System.out.println("Enero tiene 31 días. ");
					
					case 2 -> System.out.println("Febrero tiene 29 días. ");
					
					case 3 -> System.out.println("Marzo tiene 31 días. ");
					
					case 4 -> System.out.println("Abril tiene 31 días. ");
					
					case 5 -> System.out.println("Mayo tiene 30 días. ");
					
					case 6 -> System.out.println("Junio tiene 31 días. ");
					
					case 7 -> System.out.println("Julio tiene 30 días. ");
					
					case 8 -> System.out.println("Agosto tiene 31 días. ");
					
					case 9 -> System.out.println("Septiembre tiene 30 días. ");
					
					case 10 -> System.out.println("Octubre tiene 31 días. ");
					
					case 11 -> System.out.println("Noviembre tiene 30 días. ");
					
					case 12 -> System.out.println("Diciembre tiene 31 días. ");
				}
		 }
				else { 
		
		switch (mes) 
		{ 
			case 1 -> System.out.println("Enero tiene 31 días. ");
			
			case 2 -> System.out.println("Febrero tiene 28 días. ");
			
			case 3 -> System.out.println("Marzo tiene 31 días. ");
			
			case 4 -> System.out.println("Abril tiene 31 días. ");
			
			case 5 -> System.out.println("Mayo tiene 30 días. ");
			
			case 6 -> System.out.println("Junio tiene 31 días. ");
			
			case 7 -> System.out.println("Julio tiene 30 días. ");
			
			case 8 -> System.out.println("Agosto tiene 31 días. ");
			
			case 9 -> System.out.println("Septiembre tiene 30 días. ");
			
			case 10 -> System.out.println("Octubre tiene 31 días. ");
			
			case 11 -> System.out.println("Noviembre tiene 30 días. ");
			
			case 12 -> System.out.println("Diciembre tiene 31 días. ");
		}

		}

	}
}
